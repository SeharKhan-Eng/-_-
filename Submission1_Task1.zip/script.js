function calculateAge() {
    // Get the input values
    var dobDay = document.getElementById("dobDay").value;
    var dobMonth = document.getElementById("dobMonth").value;
    var dobYear = document.getElementById("dobYear").value;

    // Create a Date object using the input values
    var dob = new Date(dobYear, dobMonth - 1, dobDay);

    // Get the current date
    var currentDate = new Date();

    // Calculate the age
    var age = currentDate.getFullYear() - dob.getFullYear();

    // Adjust the age if the birthday hasn't occurred yet this year
    if (currentDate.getMonth() < dob.getMonth() || (currentDate.getMonth() === dob.getMonth() && currentDate.getDate() < dob.getDate())) {
        age--;
    }

    // Display the result
    document.getElementById("result").innerHTML = "Your age is: " + age + " years.";
}